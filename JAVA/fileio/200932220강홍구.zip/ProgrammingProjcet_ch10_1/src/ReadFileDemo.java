/**
 * Program to ReadFile
 * Author : Kang Hong Gu 
 * Programming Project1 in chapter10
 */
public class ReadFileDemo {
	public static void main(String[] args)
	{
		ReadFile test = new ReadFile("number.txt");
		test.readFile();
	}
}
